# PRD Quality Standards
# Author: Sankar Kumar Palaniappan

## The 10 Rules for a 10/10 PRD

### 1. Be Specific — Never Vague
Every requirement and metric must be measurable.
- ❌ "The system should be fast"
- ✅ "P95 end-to-end analysis latency < 30 seconds for contracts up to 20 pages"

- ❌ "Good accuracy"
- ✅ ">90% F1 score on clause detection, measured against the CUAD test set"

### 2. Cite Data — Don't Assert
Every claim about market size, cost, or user behaviour needs a source or
an explicit assumption.
- ❌ "SMBs spend a lot on legal fees"
- ✅ "43% of SMB legal issues cost £5,000 or more (Law Society, 2023)"

### 3. North Star Metric Must Be Explicit
One metric. Named. Prominent. With baseline and target.
- ❌ "We'll measure success by adoption and accuracy"
- ✅ "North Star: Average contract review time per user — baseline: 2 hrs (manual), target: <30 min with ContractIQ, tracked via session logs"

### 4. User Stories First
Every functional requirement traces back to a user story.
Format: "As a [role], I want [action] so that [outcome]"
Acceptance criteria must be testable — not subjective.

### 5. AI-Specific Sections Are Mandatory for AI Products
A generic PRD template is not enough. AI products require:
- Why agentic AI (not rule-based)
- Prompt strategy with output format constraints
- Evaluation plan with HHH framework
- Responsible AI risks per pillar (Accountability, Transparency, Fairness, Reliability)
- Component-level risk table (ML necessity, data, accuracy, bias, explainability)

### 6. Roadmap in Table Format
Prose bullets are not a roadmap. Use:
| Release | Features | Duration |

### 7. Evaluation Spreadsheet Is Required
Include a link or a structured table with headers. Minimum columns:
Contract ID | Expected output | Actual output | Precision | Recall | Expert rating | Notes

### 8. P0/P1/P2 on Everything
Every feature, requirement, and user story gets a priority label.
- P0 = launch blocker — product cannot go live without it
- P1 = important — ship in MVP if possible, required for v1.1
- P2 = nice-to-have — backlog until post-launch

### 9. Responsible AI Is Not a Checkbox
The Responsible AI section must answer specific questions per pillar
(Accountability, Transparency, Fairness, Reliability & Safety), not just
acknowledge that risks exist.

### 10. End with Assumptions — Always
Any reviewer will challenge what isn't stated. List every assumption
explicitly. This shows intellectual honesty and makes the PRD defensible.

---

## Common PRD Failures and How to Fix Them

| Failure | Fix |
|---|---|
| Functional requirements in prose, not user stories | Convert top 5+ to "As a [role]…" format |
| North Star not named | Add explicit "North Star Metric:" label with baseline + target |
| Metrics scattered across sections | Consolidate into a single metrics table in Problem Definition |
| All risk checks show PASS | Include at least 1–2 honest FAILs with mitigation plan |
| Roadmap in bullets, not table | Reformat to Releases \| Features \| Duration table |
| Eval spreadsheet missing | Add placeholder link with column headers defined |
| Prompt strategy vague | Add output format spec per task (JSON schema, word limits) |
| MOAT not defended | Name specific competitors and explain why they cannot replicate it |
| Cost/accuracy tradeoff table blank | Fill in actual technology choices made during development |
| Silent gaps (no open questions) | Flag every unknown as an explicit Open Question |

---

## Prioritization Framework (P0/P1/P2)

**P0 — Launch Blocker**
The product cannot ship without this. If missing, the core value proposition fails.
Examples: document upload, AI extraction, basic risk flags, user authentication.

**P1 — Important**
Significant value; should ship in MVP if capacity allows. Required by v1.1.
Examples: export to PDF, Q&A chat, integration with Google Drive.

**P2 — Nice-to-Have**
Enhances the product but doesn't block the core use case.
Examples: contract comparison, multi-language support, CRM integration.

---

## What Makes a Strong MOAT for an AI Product?

A defensible MOAT is something technically, data-wise, or strategically hard
for competitors to replicate quickly. For AI products, strong MOATs include:

1. **Proprietary training data** — you have access to data competitors don't
   (e.g. anonymised contract corpus from 10,000 SMB customers)
2. **Domain-specific fine-tuning** — a model trained on your specific use case
   outperforms a generic LLM on your task
3. **Workflow integrations** — deeply embedded in customer tools (Salesforce,
   DocuSign) creating switching costs
4. **Network effects** — the more users, the better the model gets
   (feedback loop from corrections)
5. **Speed to value** — first-mover advantage in an underserved segment before
   incumbents notice

Weak MOAT claims to avoid:
- "We use AI" (everyone does)
- "We're cheaper" (not defensible long-term)
- "We have a better UX" (easily copied)
