# PRD Self-Evaluation Checklist
# Author: Sankar Kumar Palaniappan

Use this checklist to verify a PRD before delivering or submitting it.
Every item should be answered with **substance** — no `[TBD]` or placeholder text.
Any unknowns must be listed as explicit **Open Questions** in the PRD.

---

## Week 1

### Section 1. Problem Definition

- [ ] Have I clearly articulated the problem and job-to-be-done?
- [ ] Have I defined the customer persona(s) with specific roles, industries, and needs?
- [ ] Have I validated the problem with real data or market research?
- [ ] Have I explained why this problem is worth solving, especially for my target user?
- [ ] Have I defined a clear and defensible MOAT?
- [ ] Have I justified the use of Agentic AI over rule-based systems?
- [ ] Have I listed types of unstructured data involved and explained the need for ML / LLMs over rule-based solution?
- [ ] Have I differentiated the solution from ChatGPT, copilots, Claude Code and Co-Work, or other tools?

#### Core Metrics

- [ ] Have I defined a clear North Star metric?
- [ ] Have I listed at least 1–2 primary metrics (e.g. accuracy, time saved)?
- [ ] Have I included secondary or supporting metrics (e.g. user adoption, cost reduction)?
- [ ] Are metrics measurable, and can they be tracked over time?

---

### Section 2. Solution Definition

- [ ] Have I included a visual user flow (input → processing → output)?
- [ ] Have I addressed potential AI drawbacks (hallucination, explainability, etc.)?
- [ ] Have I listed core functional requirements in user story format?
- [ ] Have I clearly described agent capabilities and system behavior?

---

## Week 2

### Section 3. Prioritization

- [ ] Have I broken the Agentic workflow into components (e.g. ingestion, extraction, summarization)?
- [ ] Have I conducted a risk assessment for each component?
- [ ] Have I specified ML feasibility, data availability, accuracy expectations, and explainability?
- [ ] Have I prioritized features based on risk, cost, and value?
- [ ] Have I clearly narrowed scope to an MVP with rationale?

---

### Section 4. Roadmap

- [ ] Have I listed clear phases: MVP, MVP1, Launch, Iteration?
- [ ] Have I defined feature sets and target durations for each phase?
- [ ] Have I linked roadmap items back to priorities and risks?

---

## Week 3

### Section 5. Implementation Plan

#### Model Requirements

- [ ] Have I listed model selection criteria and requirements?
- [ ] Have I justified the chosen model(s) against alternatives?

---

### Section 6. Evaluation Plan

- [ ] Have I described how AI performance will be evaluated over time?
- [ ] Have I identified datasets or ground truth sources for benchmarking?
- [ ] Have I defined accuracy thresholds or HHH (Helpful, Honest, Harmless) scores?
- [ ] Have I included a link or plan for maintaining an evaluation spreadsheet?

#### Launch Plan

- [ ] Have I defined launch criteria and a go / no-go decision framework?
- [ ] Have I described the experimentation or A/B testing plan for launch?
- [ ] Have I defined how AI performance will be monitored post-launch?

---

## Week 4

### Section 7. Data Requirements & Prompt Strategy

#### Data Requirements

- [ ] Have I listed the data strategy for the product (sources, formats, pipelines)?
- [ ] Have I addressed data quality, availability, and any compliance constraints?

#### Prompt Strategy

- [ ] Have I described few-shot, CoT (Chain-of-Thought), or conditional prompting where applicable?
- [ ] Have I defined prompt constraints and output formats per task type?
- [ ] Have I included plans for improving prompts based on user feedback and error analysis?

---

### Section 8. Responsible AI Risks & Mitigation

- [ ] Have I assessed risks across Accountability, Transparency, Fairness, and Reliability?
- [ ] Have I planned for human-in-the-loop and fallback paths?
- [ ] Have I listed sensitive use cases and mitigation strategies?
- [ ] Have I addressed bias, hallucination, and safe failure modes?

---

## Week 5

### Section 9. Pricing & Cost Structure

- [ ] Have I explained any tradeoffs made between accuracy and cost?
- [ ] Have I provided a breakdown of development costs (infra + manpower)?
- [ ] Have I listed ongoing operational costs?
- [ ] Have I calculated market size (TAM, SAM)?
- [ ] Have I defined potential revenue scenarios?
- [ ] Have I selected a pricing model (subscription, usage-based, freemium, etc.) with rationale?
- [ ] Have I included a directional pricing recommendation?

---

## Final Check

- [ ] All sections filled with substance (no `[TBD]` or placeholder text)
- [ ] North Star metric clearly labelled and prominent
- [ ] User stories present for all functional requirements
- [ ] Roadmap in table format: Releases | Features | Duration
- [ ] Evaluation spreadsheet linked or structured table included
- [ ] All unknowns listed as explicit Open Questions
