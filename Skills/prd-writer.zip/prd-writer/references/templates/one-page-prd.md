# One-Page PRD Template
# Author: Sankar Kumar Palaniappan

Use for smaller features, quick stakeholder alignment, or early-stage scoping.

---

# [Feature Name] — One-Page PRD

**Date:** [Date] | **Author:** Sankar Kumar Palaniappan | **Status:** Draft

### Problem
[2–3 sentences: who has this problem, what it is, why it matters now. Cite data.]

### Solution
[2–3 sentences: what we're building and how it solves the problem.]

### Why Now?
- [Driver 1: customer demand, competitive pressure, or market timing]
- [Driver 2: regulatory or strategic alignment]
- [Driver 3: technical feasibility now available]

### North Star Metric
[Single metric] — baseline: [X] → target: [Y] — tracked via [tool/method]

### Success Metrics
| Metric | Current | Target | Tracked via |
|---|---|---|---|
| [Primary KPI] | [X] | [Y] | [Method] |
| [Secondary KPI] | [X] | [Y] | [Method] |

### Scope
**In:** [Feature 1], [Feature 2], [Feature 3]
**Out:** [Excluded item 1], [Excluded item 2]

### User Flow (as user stories)
- As a [role], I want [action] so that [outcome] — P0
- As a [role], I want [action] so that [outcome] — P1

**Flow:** [Entry Point] → [Step 1] → [AI Processing] → [Output] → [Action]

### If AI-powered: Why agentic AI?
[One paragraph: what unstructured data, why rules fail, why LLMs are needed.]

### Risks
| Risk | Probability | Impact | Mitigation |
|---|---|---|---|
| [Risk 1] | H/M/L | H/M/L | [Strategy] |
| [Risk 2] | H/M/L | H/M/L | [Strategy] |

### Timeline
| Phase | Duration | Deliverable |
|---|---|---|
| Design | Week 1–2 | Mockups, user flow |
| Development | Week 3–6 | Core features (P0s) |
| Testing | Week 7 | QA + beta users |
| Launch | Week 8 | GA or limited rollout |

### Resources
Engineering: [X devs] | Design: [X] | QA: [X] | Budget: $[X]

### Open Questions
1. [Question 1]
2. [Question 2]

### Assumptions
[List assumptions made to fill any gaps.]
