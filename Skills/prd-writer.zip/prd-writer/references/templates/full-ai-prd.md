# Full AI PRD Template
# Author: Sankar Kumar Palaniappan

Use for major AI product initiatives requiring cross-functional alignment.
Covers all 9 sections of the Cohort curriculum across 5 weeks.
Every section maps 1:1 to `PRD-checklist.md` — fill all sections before submitting.

---

# [Product Name] — Product Requirements Document

**Date:** [Today's date]
**Author:** Sankar Kumar Palaniappan
**Status:** Draft
**Version:** 1.0

---

## Week 1

---

## Section 1. Problem Definition

### What problem is this solving?

[2–3 sentences: describe the specific problem, the job-to-be-done, and the pain point.
Be concrete — validate the problem with real data or market research. Avoid vague statements like "the process is slow."]

### Who are you solving this problem for? *(customer persona)*

**Primary persona:** [Role · Industry · Company size · Specific needs]

| Attribute | Detail |
|---|---|
| Role | [e.g. In-house paralegal, ops manager, HR business partner] |
| Industry | [e.g. Legal services, healthcare, retail SMB] |
| Company size | [e.g. 10–200 employees, no specialist team] |
| Behaviour | [e.g. Reviews 5–10 contracts per month manually] |
| Pain | [e.g. Spends 2–3 hrs per contract; risks missing key clauses] |

**Secondary persona (if applicable):** [Role · Industry · Specific needs]

### Why is this problem worth solving?

[Make a quantified case. Include market data, cost of the problem, or frequency data.
Address your MOAT — what will your solution provide that ChatGPT, Co-Work, or existing tools cannot?]

- **Quantified pain:** [e.g. "43% of SMB legal issues cost £5,000+ — Law Society, 2023"]
- **Market gap:** [What existing solutions miss — be specific about named competitors]
- **MOAT:** [Why your solution is defensible — proprietary data, domain fine-tuning, workflow lock-in, network effects, or first-mover advantage. Name what a competitor cannot easily replicate and why.]

### Why Agentic AI? *(justify Agentic AI over rule-based systems)*

[Explain why ML/LLMs with tools and planning are better suited than a traditional rule-based system or a plain ML model. Be concrete on all three points below.]

- **What unstructured data is involved?** [e.g. Free-form contract text, variable clause structures, diverse legal language, scanned PDFs]
- **Why rule-based systems fail:** [e.g. Regex cannot generalise across 1,000 clause variants; if-then logic breaks on edge cases]
- **Why LLMs are necessary:** [e.g. Context-aware extraction, reasoning over ambiguous language, natural language generation for summaries]
- **Differentiation from ChatGPT / copilots / Claude Code / Co-Work:** [e.g. Domain-specific fine-tuning, RAG over proprietary knowledge base, integrated into customer workflow — not a general chat interface]

### How will you know the problem is solved? — Core Metrics

**North Star Metric:**
> [Single metric that best captures core value delivered to the user. Name it explicitly.]

| Metric | Baseline | Target | How tracked |
|---|---|---|---|
| **[North Star — name it]** | [Current state] | [Goal] | [Tool / method] |

**Primary Metrics (1–2):**

| Metric | Baseline | Target | How tracked |
|---|---|---|---|
| [e.g. Clause detection accuracy] | [e.g. 0% — manual today] | [e.g. >90% F1] | [Eval suite] |
| [e.g. Time per contract review] | [e.g. 2 hrs manual] | [e.g. <30 min] | [Session logs] |

**Secondary / Supporting Metrics:**

| Metric | Baseline | Target | How tracked |
|---|---|---|---|
| [e.g. 30-day user retention] | — | [e.g. >60%] | [Analytics] |
| [e.g. NPS] | — | [e.g. >40] | [In-app survey] |
| [e.g. Cost per analysis] | — | [e.g. <$3] | [Billing logs] |

---

## Section 2. Solution Definition

### User Flows *(visual user flow: input → processing → output)*

[Describe the end-to-end flow from the user's perspective: Input → Processing → Output.
Address AI drawbacks (hallucination, explainability) within the flow — not as an afterthought.]

**Primary flow:**
`[Entry point]` → `[Step 1: User action]` → `[Step 2: AI processing]` → `[Step 3: Output]` → `[Step 4: User action]`

**Detailed flow:**

1. **Input:** [What the user does to start — upload, type, connect a data source]
2. **AI pipeline:** [What happens in the background — OCR, extraction, model call, RAG, tool use]
3. **Output:** [What the user sees — dashboard, summary, flags, recommendations, structured data]
4. **User action:** [What the user can do next — edit, export, approve, ask a follow-up question]
5. **Hallucination safeguard:** [How wrong AI output is caught or flagged before the user acts on it]
6. **Explainability:** [How the user understands why the AI said what it said — source references, confidence scores, reasoning trace]

> **Required: Attach a visual flow diagram here** (Miro, Figma, Lucidchart, or drawn sketch).
> The diagram must show distinct stages for what the **user** does vs what the **system** does.

### Functional Requirements

**User Stories:**

| ID | User Story | Acceptance Criteria | Priority |
|---|---|---|---|
| US-001 | As a [role], I want [action] so that [outcome] | [Testable criterion 1]; [criterion 2] | P0 |
| US-002 | As a [role], I want [action] so that [outcome] | [Testable criterion 1]; [criterion 2] | P0 |
| US-003 | As a [role], I want [action] so that [outcome] | [Testable criterion 1]; [criterion 2] | P1 |
| US-004 | As a [role], I want [action] so that [outcome] | [Testable criterion 1]; [criterion 2] | P1 |
| US-005 | As a [role], I want [action] so that [outcome] | [Testable criterion 1]; [criterion 2] | P2 |

> P0 = launch blocker · P1 = important, ship in MVP if possible · P2 = nice-to-have, backlog

**Agent Capabilities & System Behaviour:**

| Agent / Component | Input | Output | Autonomy level | Human-in-loop trigger |
|---|---|---|---|---|
| [e.g. Ingestion agent] | [File / URL] | [Structured text] | [Fully autonomous] | [If file unreadable] |
| [e.g. Extraction agent] | [Text] | [Structured data] | [Autonomous + review] | [If key field missing] |
| [e.g. Risk agent] | [Clauses] | [Risk flags] | [Suggests, human decides] | [Always for High-risk] |
| [e.g. Summary agent] | [Full text] | [Plain-language summary] | [Fully autonomous] | [User can edit output] |

---

## Week 2

---

## Section 3. Prioritization

### Breaking the Agentic Workflow into Components

[List each AI component in execution order. Each component will be risk-assessed below.]

1. [Component 1: e.g. Document ingestion & OCR]
2. [Component 2: e.g. Key term & clause extraction]
3. [Component 3: e.g. Risk analysis & compliance checks]
4. [Component 4: e.g. Summarisation & Q&A]

> **Required: Attach a component flow diagram here** showing how data moves through each component.

### Risk Assessment per Component

[For each component, complete the risk table. Be honest — at least 1–2 items should show FAIL with a mitigation plan.]

| Component | Check | Result | Explanation |
|---|---|---|---|
| [Component 1] | Is ML necessary? | PASS / FAIL | [Rule-based alternative considered?] |
| [Component 1] | Do you have data to train / evaluate? | PASS / FAIL | [Source and quantity of data] |
| [Component 1] | ML feasibility — can it be solved by ML / AI? | PASS / FAIL | [Feasibility reasoning] |
| [Component 1] | Can it meet accuracy requirements? | PASS / FAIL | [Target accuracy vs achievable] |
| [Component 1] | Can it scale? | PASS / FAIL | [Volume and latency at scale] |
| [Component 1] | How fast can you get feedback? | PASS / FAIL | [Feedback loop cadence] |
| [Component 1] | What are the applicable laws? | PASS / FAIL | [GDPR, HIPAA, sector-specific] |
| [Component 1] | What about bias? | PASS / FAIL | [Bias risk and mitigation] |
| [Component 1] | How transparent / explainable? | PASS / FAIL | [Explainability approach] |
| [Component 1] | How easy to judge good vs bad response? | PASS / FAIL | [Evaluation approach] |
| [Component 2] | [Repeat all checks] | | |

*Repeat for all components.*

**Overall Risk Summary:**

| Component | Risk level | Mitigation |
|---|---|---|
| [Component 1] | High / Medium / Low | [Key risk + mitigation action] |
| [Component 2] | High / Medium / Low | [Key risk + mitigation action] |
| [Component 3] | High / Medium / Low | [Key risk + mitigation action] |
| [Component 4] | High / Medium / Low | [Key risk + mitigation action] |

### Prioritize Features and Narrow Scope

[Follow the prioritization principles from the lesson "Product Roadmap & Prioritization."
List your prioritized stories below — these feed directly into the Roadmap.]

| Story ID | Title | Priority | Points | Rationale |
|---|---|---|---|---|
| US-001 | [Story title] | P0 | [5] | [Why this is a launch blocker] |
| US-002 | [Story title] | P0 | [3] | [Why this is a launch blocker] |
| US-003 | [Story title] | P1 | [5] | [Why this ships in MVP if capacity allows] |
| US-004 | [Story title] | P1 | [2] | [Why this ships in MVP if capacity allows] |
| US-005 | [Story title] | P2 | [3] | [Backlog — post-launch] |

**MVP scope rationale:** [1–2 sentences explaining why these P0/P1 stories constitute the right MVP — what is deliberately excluded and why.]

---

## Section 4. Roadmap

[Define the roadmap for your MVP as a table. Each release must have a distinct feature set and duration.
An MVP that includes everything is not an MVP — draw a clear line between launch scope and future scope.]

| Release | Features | Duration |
|---|---|---|
| MVP / MEP | [Core features that prove the concept — minimum to test the hypothesis] | [e.g. Weeks 1–6] |
| MVP 1 | [Next layer of value added after initial validation] | [e.g. Weeks 7–12] |
| Launch | [Full feature set for general availability] | [e.g. Months 4–5] |
| Iteration | [Post-launch improvements based on user feedback and eval results] | [Ongoing] |

> Each roadmap item should be linked back to the prioritized stories and risk assessment in Section 3.
> An MVP that includes everything is not an MVP — be explicit about what is out of scope and why.

**Dependencies:**
- [Cross-functional dependency 1: e.g. Data sourcing agreement with legal partner]
- [Cross-functional dependency 2: e.g. Security audit before launch]
- [Cross-functional dependency 3: e.g. Design sign-off on user flow by Week 3]

---

## Week 3

---

## Section 5. Implementation Plan

### Evaluation Strategy *(how AI performance will be evaluated over time)*

[Describe how you will evaluate AI performance — before launch and on an ongoing basis after launch.
This is how you establish ground truth and ensure the model is doing what you claim over time.]

**Ground truth sources:**
- [e.g. Publicly available labelled dataset — CUAD, SQuAD, domain-specific benchmark]
- [e.g. Expert-labelled internal test set — describe how many examples and who labels them]
- [e.g. User-corrected outputs collected post-launch (opt-in, anonymised)]

**Evaluation plan:**

| Eval type | Method | Target | Cadence |
|---|---|---|---|
| [e.g. Extraction accuracy] | [e.g. Precision / Recall / F1 vs ground truth] | [e.g. >90% F1] | [Per release] |
| [e.g. Summarisation quality] | [e.g. Expert review — accuracy & completeness] | [e.g. >90% approval] | [Monthly] |
| [e.g. Latency] | [e.g. End-to-end timing on representative input] | [e.g. <30s P95] | [Per release] |
| [e.g. User satisfaction] | [e.g. In-app survey: "Was this result accurate?"] | [e.g. >80% yes] | [Beta phase] |

**AI performance monitoring (post-launch):**
- [e.g. Automated regression suite runs on every deploy]
- [e.g. Monthly drift check — compare recent outputs to ground truth sample]
- [e.g. Alert threshold — if F1 drops >5% from baseline, trigger model review]

**Evaluation spreadsheet:**
[Add link here] — Minimum columns: `Input ID | Expected output | Actual output | Precision | Recall | Expert rating | Notes`

> Copy the template sheet: https://docs.google.com/spreadsheets/d/1j82be2ibJ7lnf2ONGNeqf0LxBVitZvl2XmiFjCmH44A/edit?usp=sharing

### Model Requirements *(model selection criteria)*

[Define the criteria used to select your model. Every requirement needs a rationale — "we just picked GPT-4" is not sufficient.
After completing the table, justify the chosen model(s) against at least one alternative you considered and rejected.]

| Criteria | Requirement | Rationale |
|---|---|---|
| Open vs. Closed Source | [Open / Closed / Either] | [e.g. "No resources to host open-source model; using closed API for MVP"] |
| Context Window | [e.g. 128K+ tokens] | [e.g. "Need to pass full contract text in a single call"] |
| Modalities | [e.g. Text + Vision] | [e.g. "Users upload scanned PDFs; need OCR + language understanding"] |
| Fine-Tuning Capability | [Required / Not required] | [e.g. "Will fine-tune v2 on proprietary contract corpus"] |
| Latency | [e.g. <10s per call] | [e.g. "Real-time UX requirement — user waits for output"] |
| Accuracy | [Priority level + threshold] | [e.g. "High priority — regulatory context; >90% precision required"] |
| Parameters | [e.g. N/A — using hosted API] | [e.g. "Considered smaller fine-tuned model; rejected due to general knowledge needs"] |
| Time to Market | [Priority level] | [e.g. "Medium — targeting 3-month MVP; using fastest-to-integrate option"] |

[Justify the chosen model(s) against at least one alternative considered and rejected.]

---

## Section 6. Evaluation Plan

### HHH Evaluation *(accuracy thresholds — Helpful, Honest, Harmless)*

[Evaluate your product against the Helpful, Honest, Harmless framework.
Be specific — name real risks and concrete mitigations, not generic statements.]

| Pillar | Strength | Risk | Mitigation |
|---|---|---|---|
| Helpful | [What genuine value does the AI deliver for the user?] | [Where might it fail to help or mislead?] | [How do you catch or prevent this?] |
| Honest | [How do outputs stay grounded in real data / sources?] | [Where might the AI hallucinate or overstate confidence?] | [e.g. RAG + source citations + strict prompt: "only use provided text"] |
| Harmless | [Why is this product low-risk for the typical user?] | [What is the worst-case outcome if the AI is wrong?] | [e.g. Disclaimer; human review required for all High-risk outputs] |

### Launch Plan *(launch criteria and go / no-go decision framework)*

[Define the launch criteria that must be met at each stage before proceeding.
A go/no-go decision requires measurable thresholds — not qualitative judgement.]

| Launch stage | Helpful | Honest | Harmless | Go criteria |
|---|---|---|---|---|
| Measurement launch (1–2%) | [Target] | [Target] | [Target] | [e.g. <1% crash rate; core flow works end-to-end] |
| Beta launch (2–10%) | [Target] | [Target] | [Target] | [e.g. >80% user satisfaction; F1 >85%; latency <30s] |
| Full launch | [Target] | [Target] | [Target] | [e.g. F1 >90%; latency <30s P95; security audit passed] |

**Experimentation plan:**
- [e.g. A/B test: AI summary vs manual summary — measure time-to-decision]
- [e.g. Holdback: 5% of users see v1 model vs v2 model — measure F1 and satisfaction]

---

## Week 4

---

## Section 7. Data Requirements & Prompt Strategy

### Data Requirements

[Describe the full data strategy — what data the product needs to function, where it comes from,
how it is prepared, and how it is maintained over time.]

| Area | Description |
|---|---|
| Model Fine-Tuning | [Are you fine-tuning? If yes, explain why — tone/style, functional output, or specialised knowledge. If no, explain why prompt engineering is sufficient.] |
| Data Preparation | [Is this data used for fine-tuning, for RAG, or for evaluation (ground truth)? Describe your collection and preparation process.] |
| Data Quantity | [How much labelled data do you need? e.g. "100 annotated contracts for fine-tuning; 50 held out for evaluation"] |
| Iterative Data Collection | [How will you collect more data over time? e.g. "User correction opt-in; expert review queue; synthetic data augmentation"] |
| Iterative Fine-Tuning | [If fine-tuning: describe the cadence and trigger for retraining. e.g. "Quarterly, or when F1 drops >3%"] |
| Knowledge Base (RAG) | [What documents or data will populate the RAG knowledge base? Format, update frequency, and ownership.] |

**Data quality and compliance:**
- [e.g. PII handling — anonymise before any model call; no customer data used for training without consent]
- [e.g. Data residency — all data stored in [region]; compliant with GDPR / HIPAA / applicable regulation]
- [e.g. Quality threshold — reject inputs with <80% OCR confidence before extraction]

### Prompt Strategy

[Define the prompting approach per task type. Output format constraints are mandatory — vague prompts produce unpredictable outputs.]

| Task | Technique | Rationale |
|---|---|---|
| [e.g. Key term extraction] | [Few-shot] | [e.g. Consistent structured output across variable input formats] |
| [e.g. Risk analysis] | [Chain-of-Thought] | [e.g. Step-by-step reasoning reduces missed flags on ambiguous clauses] |
| [e.g. Summarisation] | [Zero-shot + system prompt] | [e.g. Open-ended generation; model has sufficient context from RAG] |
| [e.g. Q&A] | [RAG + iterative prompting] | [e.g. Grounds all answers in retrieved contract text; prevents hallucination] |

**Output format constraints:**
- [Task 1] output: [e.g. JSON — `{ "field": string, "value": string, "clause_ref": string }`]
- [Task 2] output: [e.g. Structured list — `{ "clause": string, "risk_level": "High|Medium|Low", "explanation": string }`]
- [Task 3] output: [e.g. Max 300 words, plain English, paragraph format, no bullet points]

**Prompt improvement plan:**
- [e.g. Maintain a versioned prompt library (v1, v2…) in a shared doc]
- [e.g. A/B test prompt variants on the eval set monthly]
- [e.g. Log user corrections as failure signals — trigger prompt review if correction rate >5%]
- [Plan for continuously improving prompts based on user feedback and error analysis]

---

## Section 8. Responsible AI Risks & Mitigation

[Assess your product across all four pillars. Answer every question specifically — "we will comply with regulations" is not an answer.]

### Accountability

| Question | Answer |
|---|---|
| What are the efficacy and limitations of this product? | [What it does well; where it will struggle; what it must not be used for] |
| What compliance policies apply to managing sensitive data? | [GDPR, HIPAA, SOC 2, sector-specific — which apply and how] |
| How will sensitive data be managed? | [Encryption at rest/in transit; access controls; data retention policy; deletion process] |
| What sensitive use cases exist and what are the mitigations? | [e.g. High-stakes decisions — financial, legal, medical; list each sensitive use case and the specific mitigation strategy] |
| Human oversight, control, and human-in-the-loop paths? | [Disclaimers shown to users; human-in-the-loop triggers per agent; fallback paths if AI is wrong; audit logs; override capability] |

### Transparency

| Question | Answer |
|---|---|
| What are the direct and indirect use cases of this solution? | [Intended use; plausible misuse or unintended use cases] |
| How are results generated — what is considered at each step? | [Which data, which model, which steps — enough for a user to understand why an output appeared] |
| What benchmarks need to be shared with users? | [e.g. "90% F1 on clause detection"; confidence scores shown inline] |
| What disclosures are required? | [e.g. "Not legal advice"; AI-generated label; confidence label on High-risk flags] |

### Fairness

| Question | Answer |
|---|---|
| Which groups will be underrepresented — where will the product not work well? | [e.g. Non-English contracts; niche industries; small companies with atypical contract formats] |
| Why don't they work, and what is the plan to close the gap? | [Training data gap; plan to expand corpus; minimum data needed and collection plan] |
| What test / feedback loop will identify groups that are not working well? | [e.g. Monthly performance audit by segment; user flag for "this didn't work for my contract"] |

### Reliability & Safety

| Question | Answer |
|---|---|
| What is a reliable and safe product experience — what are acceptable error rates? | [e.g. <5% critical errors (missed High-risk clause); <1% crash rate] |
| What are the consequences of bad input or wrong output? | [e.g. OCR error → wrong clause extraction → user misses key term] |
| What is the recovery plan if the system fails? | [e.g. Rollback to previous model version within 2h; fallback to manual review queue] |
| How will system health be monitored, and how will customers be communicated with? | [e.g. Automated alerts, on-call rotation, status page; in-app banner + email within 1h of P0 incident] |

---

## Week 5

---

## Section 9. Pricing & Cost Structure

### Costs & Accuracy Trade-offs

[For each infrastructure choice, explain what was selected, why, and what was traded away. Be honest about trade-offs — this is not a justification exercise.]

| # | Item | What we use | Why we chose this | Trade-off |
|---|---|---|---|---|
| 1 | Framework | [e.g. LangChain / FastAPI] | [e.g. Rapid orchestration, large community] | [e.g. Vendor lock-in risk] |
| 2 | LLM for inference | [e.g. GPT-4o via API] | [e.g. Best reasoning, large context window] | [e.g. High token cost at scale] |
| 3 | Libraries / Tools | [e.g. pypdf, tiktoken, Tesseract] | [e.g. Open source, no data egress] | [e.g. Lower OCR accuracy than AWS Textract] |
| 4 | User interface | [e.g. React + Tailwind] | [e.g. Team familiarity, fast iteration] | [e.g. SSR not supported out of the box] |
| 5 | Vector database | [e.g. Pinecone / Chroma] | [e.g. Managed, fast similarity search] | [e.g. Monthly cost at scale] |
| 6 | Hosting | [e.g. AWS ECS + S3] | [e.g. Scales with usage; team familiar with AWS] | [e.g. Cold start latency on ECS] |
| 7 | Dev editor | [e.g. VS Code + Copilot] | [e.g. Developer standard] | — |

### Development Costs (One-Time / MVP)

**Infrastructure:**

| Item | Cost |
|---|---|
| Cloud hosting & storage setup | $[X] |
| LLM API credits (dev + test) | $[X] |
| OCR / document processing service | $[X] |
| DevOps tooling & CI/CD | $[X] |
| Security & compliance setup | $[X] |
| Miscellaneous licensing | $[X] |
| **Infrastructure subtotal** | **$[X]** |

**Manpower (Resource costs):**

| Role | Qty | Monthly cost | Duration | Subtotal |
|---|---|---|---|---|
| Product Manager | 1 | $[X] | [X] months | $[X] |
| Lead Engineer | 1 | $[X] | [X] months | $[X] |
| Backend Engineer | [X] | $[X] | [X] months | $[X] |
| ML / Data Scientist | 1 | $[X] | [X] months | $[X] |
| Frontend Engineer | 1 | $[X] | [X] months | $[X] |
| QA Engineer | 1 | $[X] | [X] months | $[X] |
| UX Designer | 0.5–1 | $[X] | [X] months | $[X] |
| **Manpower subtotal** | | | | **$[X]** |
| **Total one-time cost** | | | | **$[X]** |

### Operational Costs (Recurring Monthly)

| Item | Monthly cost |
|---|---|
| Cloud hosting & storage | $[X] |
| LLM API usage | $[X] |
| OCR / document processing | $[X] |
| Monitoring & observability | $[X] |
| Security & compliance | $[X] |
| CI/CD & DevOps tools | $[X] |
| Third-party integrations | $[X] |
| Manpower (maintenance team) | $[X] |
| **Monthly total** | **$[X]** |

### Market Size

- **TAM:** [Total Addressable Market — global or broad market size with source and year]
- **SAM:** [Serviceable Addressable Market — realistic reachable segment given your go-to-market]
- **SOM:** [Serviceable Obtainable Market — your target in first 12–24 months with rationale]

### Revenue Potential *(define revenue scenarios)*

[Define at least three revenue scenarios — conservative, target, and optimistic.
Each must be grounded in your SAM/SOM figures above, not arbitrary.]

| Scenario | Customers (Yr 3) | ARPU | ARR |
|---|---|---|---|
| Conservative | [X] | $[X] | $[X] |
| Target | [X] | $[X] | $[X] |
| Optimistic | [X] | $[X] | $[X] |

### Pricing Models

[Evaluate each model. Select one primary model and give a clear rationale.]

| Model | Pros | Cons | Verdict |
|---|---|---|---|
| Per-document / usage | [e.g. Pay-as-you-go; low barrier to try] | [e.g. Unpredictable revenue; churn risk] | [e.g. Offered as add-on only] |
| Subscription tiers | [e.g. Predictable ARR; encourages habitual use] | [e.g. Tier sizing complexity] | [e.g. Primary model — see below] |
| Usage-based | [e.g. Scales with value delivered] | [e.g. Unpredictable cost for customer] | [e.g. Hybrid option at enterprise tier] |
| Freemium | [e.g. Drives top-of-funnel adoption] | [e.g. Conversion risk; support cost] | [e.g. Free trial only — 14 days] |

### Directional Pricing

| Plan | Price | Includes | Target user |
|---|---|---|---|
| Free trial | $0 / 14 days | [X analyses / documents] | All new sign-ups |
| Starter | $[X] / month | [X] analyses · [X] users | [Persona] |
| Growth | $[X] / month | [X] analyses · [X] users | [Persona] |
| Pro / Enterprise | $[X] / month | Unlimited · all features · SLA | [Persona] |

**Value anchor:** "$[X]/month = less than [one hour of lawyer time / one contract review / one compliance incident] — and you get [X] analyses."

---

## Open Questions

[List every question that could not be answered from available context.
Each open question must have an owner and a resolution date.]

| # | Question | Owner | Due |
|---|---|---|---|
| 1 | [Unresolved question] | [Name / team] | [Date] |
| 2 | [Unresolved question] | [Name / team] | [Date] |
| 3 | [Unresolved question] | [Name / team] | [Date] |

---

## Assumptions Made

[List every assumption made to fill gaps. A reviewer will probe these.
Being explicit here is a sign of intellectual honesty, not weakness.]

- [e.g. Assumed target market is English-speaking unless stated otherwise]
- [e.g. Assumed GPT-4 class model as the LLM baseline for cost estimates]
- [e.g. Assumed 6-month MVP timeline based on a team of ~6–8 FTEs]
- [Add all product-specific assumptions here]
