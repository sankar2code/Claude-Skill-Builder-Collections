# Feature Brief & Agile Epic Templates
# Author: Sankar Kumar Palaniappan

---

# Feature Brief Template

Use for early-stage, unvalidated ideas or discovery-phase features.

---

# Feature Brief: [Feature Name]

**Date:** [Date] | **Author:** Sankar Kumar Palaniappan | **Status:** Exploration

### Context
[Why are we considering this? What signal prompted it — user feedback,
competitor move, internal request, data insight?]

### Hypothesis
> We believe that **[building this feature]**
> For **[these users]**
> Will **[achieve this outcome]**
> We'll know we're right when **[we see this specific metric change by this amount]**

### Proposed Solution
[High-level approach — 3–5 sentences. What it does, not how it's built.]

### Why AI? (if applicable)
[One paragraph: what unstructured data is involved, why a rule-based approach
would fail, what the AI adds that deterministic logic can't.]

### Effort Estimate
- **Size:** XS | S | M | L | XL
- **Confidence:** High | Medium | Low
- **Rough timeline:** [X weeks from kickoff to shipped]

### Next Steps
- [ ] User research to validate the problem (owner: [name], by [date])
- [ ] Design exploration / concept mockups (owner: [name], by [date])
- [ ] Technical spike to assess ML feasibility (owner: [name], by [date])
- [ ] Stakeholder review and prioritization (owner: [name], by [date])

### Open Questions
1. [Blocking question 1]
2. [Blocking question 2]

---

# Agile Epic Template

Use when the team works in sprints and needs story-based structure.

---

# Epic: [Epic Name]

**Epic ID:** EPIC-XXX | **Quarter:** QX 20XX | **Status:** Discovery
**Author:** Sankar Kumar Palaniappan

### Problem Statement
[2–3 sentences: what user problem this epic addresses and why it matters now.]

### Goals & Objectives
1. [Objective 1 — measurable outcome]
2. [Objective 2 — measurable outcome]
3. [Objective 3 — measurable outcome]

### North Star Metric
[Single metric] — baseline: [X] → target: [Y] — tracked via [method]

### Success Metrics
| Metric | Target | Tracked via |
|---|---|---|
| [Metric 1] | [Target] | [Method] |
| [Metric 2] | [Target] | [Method] |

### User Stories

| Story ID | User Story | Acceptance Criteria | Priority | Points | Status |
|---|---|---|---|---|---|
| US-001 | As a [role], I want [action] so that [outcome] | [Criteria] | P0 | [5] | To Do |
| US-002 | As a [role], I want [action] so that [outcome] | [Criteria] | P0 | [3] | To Do |
| US-003 | As a [role], I want [action] so that [outcome] | [Criteria] | P1 | [5] | To Do |
| US-004 | As a [role], I want [action] so that [outcome] | [Criteria] | P1 | [2] | To Do |
| US-005 | As a [role], I want [action] so that [outcome] | [Criteria] | P2 | [3] | Backlog |

### Dependencies
- [Team / System 1 — what we need from them and when]
- [Team / System 2 — what we need from them and when]

### Acceptance Criteria (Epic Level)
- [ ] All P0 stories complete and QA-approved
- [ ] North Star metric baseline established
- [ ] Performance targets met (per NFRs)
- [ ] Security review passed
- [ ] Documentation updated for affected surfaces
- [ ] Monitoring and alerting in place

### Assumptions
[List assumptions made to scope this epic.]
